import java.util.Random;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

// Base class - Device
class Device {
    private String type;
    private double price;
    private double weight;

    public Device(String type, double price, double weight) {
        this.type = type;
        this.price = price;
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }

    public double getWeight() {
        return weight;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}

// Derived class - Smartphone
class Smartphone extends Device {
    private double screenSize;
    private int cameraResolution;

    public Smartphone(String type, double price, double weight, double screenSize, int cameraResolution) {
        super(type, price, weight);
        this.screenSize = screenSize;
        this.cameraResolution = cameraResolution;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public int getCameraResolution() {
        return cameraResolution;
    }
}

// Derived class - Laptop
class Laptop extends Device {
    private String processor;
    private int ramSize;

    public Laptop(String type, double price, double weight, String processor, int ramSize) {
        super(type, price, weight);
        this.processor = processor;
        this.ramSize = ramSize;
    }

    public String getProcessor() {
        return processor;
    }

    public int getRamSize() {
        return ramSize;
    }
}

// Derived class - Tablet
class Tablet extends Device {
    private String operatingSystem;
    private boolean hasStylus;

    public Tablet(String type, double price, double weight, String operatingSystem, boolean hasStylus) {
        super(type, price, weight);
        this.operatingSystem = operatingSystem;
        this.hasStylus = hasStylus;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public boolean hasStylus() {
        return hasStylus;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of devices (1-20): ");
        int numDevices = scanner.nextInt();

        if (numDevices < 1 || numDevices > 20) {
            System.out.println("Invalid input. Please enter a number between 1 and 20.");
            return;
        }

        ArrayList<Device> devices = new ArrayList<>();
        Random random = new Random();
        String[] deviceTypes = { "Smartphone", "Laptop", "Tablet" };

        for (int i = 0; i < numDevices; i++) {
            String type = deviceTypes[random.nextInt(3)];
            double price = 100 + random.nextDouble() * 2000; // Random price between $100 and $2100
            double weight = 100 + random.nextDouble() * 900; // Random weight between 100g and 1000g

            if (type.equals("Smartphone")) {
                double screenSize = 4.0 + random.nextDouble() * 5.0; // Random screen size between 4.0 and 9.0 inches
                int cameraResolution = 5 + random.nextInt(16); // Random camera resolution between 5MP and 20MP
                devices.add(new Smartphone(type, price, weight, screenSize, cameraResolution));
            } else if (type.equals("Laptop")) {
                String processor = "Intel Core i" + (random.nextInt(11) + 1); // Random Intel Core iX processor
                int ramSize = 4 + random.nextInt(9) * 4; // Random RAM size in multiples of 4GB (4GB, 8GB, 12GB, ...)
                devices.add(new Laptop(type, price, weight, processor, ramSize));
            } else if (type.equals("Tablet")) {
                String[] osOptions = { "Android", "iOS", "Windows" };
                String operatingSystem = osOptions[random.nextInt(3)];
                boolean hasStylus = random.nextBoolean();
                devices.add(new Tablet(type, price, weight, operatingSystem, hasStylus));
            }
        }

        scanner.close();

        // Calculate and display information
        HashSet<String> distinctDeviceTypes = new HashSet<>();
        double totalDevicePrice = 0;
        double totalDeviceWeight = 0;

        for (Device device : devices) {
            distinctDeviceTypes.add(device.getType());
            totalDevicePrice += device.getPrice();
            totalDeviceWeight += device.getWeight();
        }

        System.out.println("Number of distinct device types created: " + distinctDeviceTypes.size());
        System.out.println("Total price of all devices: $" + totalDevicePrice);
        System.out.println("Total weight of all devices: " + totalDeviceWeight + " grams");
    }
}
